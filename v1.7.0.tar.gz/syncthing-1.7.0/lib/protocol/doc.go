// Copyright (C) 2014 The Protocol Authors.

// Package protocol implements the Block Exchange Protocol.
package protocol
